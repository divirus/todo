--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.4 (Ubuntu 10.4-2.pgdg18.04+1)
-- Dumped by pg_dump version 10.4 (Ubuntu 10.4-2.pgdg18.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.tasks_detail DROP CONSTRAINT taskdetail_task;
ALTER TABLE ONLY public.tasks DROP CONSTRAINT status_fk;
ALTER TABLE ONLY public.tasks DROP CONSTRAINT category_fk;
DROP INDEX public.fki_tasks_status;
DROP INDEX public.fki_tasks_category_fk;
DROP INDEX public.fki_taskdetail_task;
ALTER TABLE ONLY public.task_history DROP CONSTRAINT task_history_pk;
ALTER TABLE ONLY public.tags DROP CONSTRAINT tags_pk;
ALTER TABLE ONLY public.status DROP CONSTRAINT status_pk;
ALTER TABLE ONLY public.tasks DROP CONSTRAINT "idTask";
ALTER TABLE ONLY public.tasks_detail DROP CONSTRAINT detail_id;
ALTER TABLE ONLY public.category DROP CONSTRAINT category_pk;
ALTER TABLE public.tasks_detail ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tasks ALTER COLUMN id_task DROP DEFAULT;
ALTER TABLE public.task_history ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tags ALTER COLUMN id_tag DROP DEFAULT;
ALTER TABLE public.status ALTER COLUMN id_status DROP DEFAULT;
ALTER TABLE public.category ALTER COLUMN id_category DROP DEFAULT;
DROP SEQUENCE public.tasks_id_task_seq;
DROP SEQUENCE public.tasks_detail_id_seq;
DROP TABLE public.tasks_detail;
DROP TABLE public.tasks;
DROP SEQUENCE public.task_history_id_seq;
DROP TABLE public.task_history;
DROP SEQUENCE public.tags_id_tag_seq;
DROP TABLE public.tags;
DROP SEQUENCE public.status_id_status_seq;
DROP TABLE public.status;
DROP SEQUENCE public.category_id_category_seq;
DROP TABLE public.category;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: category; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.category (
    category_name character varying(255),
    id_category integer NOT NULL
);


--
-- Name: category_id_category_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.category_id_category_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: category_id_category_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.category_id_category_seq OWNED BY public.category.id_category;


--
-- Name: status; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.status (
    status_name character varying(255),
    id_status integer NOT NULL
);


--
-- Name: status_id_status_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.status_id_status_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: status_id_status_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.status_id_status_seq OWNED BY public.status.id_status;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tags (
    id_tag integer NOT NULL,
    tag_name character varying(255) NOT NULL
);


--
-- Name: tags_id_tag_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tags_id_tag_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tags_id_tag_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tags_id_tag_seq OWNED BY public.tags.id_tag;


--
-- Name: task_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.task_history (
    id integer NOT NULL,
    id_task integer NOT NULL,
    history character varying(512),
    date date DEFAULT CURRENT_DATE NOT NULL
);


--
-- Name: task_history_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.task_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: task_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.task_history_id_seq OWNED BY public.task_history.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    date_add date DEFAULT CURRENT_DATE NOT NULL,
    date_refresh date DEFAULT CURRENT_DATE,
    active bit(1) NOT NULL,
    header character varying(255) NOT NULL,
    tag text,
    status integer NOT NULL,
    id_task integer NOT NULL,
    id_category integer,
    done character varying
);


--
-- Name: tasks_detail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks_detail (
    id integer NOT NULL,
    id_task integer NOT NULL,
    name character varying(255),
    date_refresh date DEFAULT CURRENT_DATE,
    done character varying
);


--
-- Name: tasks_detail_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tasks_detail_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tasks_detail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tasks_detail_id_seq OWNED BY public.tasks_detail.id;


--
-- Name: tasks_id_task_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tasks_id_task_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tasks_id_task_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tasks_id_task_seq OWNED BY public.tasks.id_task;


--
-- Name: category id_category; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category ALTER COLUMN id_category SET DEFAULT nextval('public.category_id_category_seq'::regclass);


--
-- Name: status id_status; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.status ALTER COLUMN id_status SET DEFAULT nextval('public.status_id_status_seq'::regclass);


--
-- Name: tags id_tag; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags ALTER COLUMN id_tag SET DEFAULT nextval('public.tags_id_tag_seq'::regclass);


--
-- Name: task_history id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_history ALTER COLUMN id SET DEFAULT nextval('public.task_history_id_seq'::regclass);


--
-- Name: tasks id_task; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id_task SET DEFAULT nextval('public.tasks_id_task_seq'::regclass);


--
-- Name: tasks_detail id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks_detail ALTER COLUMN id SET DEFAULT nextval('public.tasks_detail_id_seq'::regclass);


--
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.category (category_name, id_category) FROM stdin;
\.
COPY public.category (category_name, id_category) FROM '$$PATH$$/2975.dat';

--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.status (status_name, id_status) FROM stdin;
\.
COPY public.status (status_name, id_status) FROM '$$PATH$$/2972.dat';

--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tags (id_tag, tag_name) FROM stdin;
\.
COPY public.tags (id_tag, tag_name) FROM '$$PATH$$/2977.dat';

--
-- Data for Name: task_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.task_history (id, id_task, history, date) FROM stdin;
\.
COPY public.task_history (id, id_task, history, date) FROM '$$PATH$$/2981.dat';

--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tasks (date_add, date_refresh, active, header, tag, status, id_task, id_category, done) FROM stdin;
\.
COPY public.tasks (date_add, date_refresh, active, header, tag, status, id_task, id_category, done) FROM '$$PATH$$/2970.dat';

--
-- Data for Name: tasks_detail; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tasks_detail (id, id_task, name, date_refresh, done) FROM stdin;
\.
COPY public.tasks_detail (id, id_task, name, date_refresh, done) FROM '$$PATH$$/2974.dat';

--
-- Name: category_id_category_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.category_id_category_seq', 3, true);


--
-- Name: status_id_status_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.status_id_status_seq', 4, true);


--
-- Name: tags_id_tag_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tags_id_tag_seq', 5, true);


--
-- Name: task_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.task_history_id_seq', 46, true);


--
-- Name: tasks_detail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tasks_detail_id_seq', 16, true);


--
-- Name: tasks_id_task_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tasks_id_task_seq', 23, true);


--
-- Name: category category_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.category
    ADD CONSTRAINT category_pk PRIMARY KEY (id_category);


--
-- Name: tasks_detail detail_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks_detail
    ADD CONSTRAINT detail_id PRIMARY KEY (id);


--
-- Name: tasks idTask; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT "idTask" PRIMARY KEY (id_task);


--
-- Name: status status_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT status_pk PRIMARY KEY (id_status);


--
-- Name: tags tags_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pk PRIMARY KEY (id_tag);


--
-- Name: task_history task_history_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.task_history
    ADD CONSTRAINT task_history_pk PRIMARY KEY (id);


--
-- Name: fki_taskdetail_task; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fki_taskdetail_task ON public.tasks_detail USING btree (id_task);


--
-- Name: fki_tasks_category_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fki_tasks_category_fk ON public.tasks USING btree (id_category);


--
-- Name: fki_tasks_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fki_tasks_status ON public.tasks USING btree (status);


--
-- Name: tasks category_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT category_fk FOREIGN KEY (id_category) REFERENCES public.category(id_category);


--
-- Name: tasks status_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT status_fk FOREIGN KEY (status) REFERENCES public.status(id_status);


--
-- Name: tasks_detail taskdetail_task; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks_detail
    ADD CONSTRAINT taskdetail_task FOREIGN KEY (id_task) REFERENCES public.tasks(id_task);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

